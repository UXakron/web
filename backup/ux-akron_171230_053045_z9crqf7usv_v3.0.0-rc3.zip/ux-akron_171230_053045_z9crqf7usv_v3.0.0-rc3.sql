-- MySQL dump 10.13  Distrib 5.5.58, for debian-linux-gnu (x86_64)
--
-- Host: db.uxakron.com    Database: uxakron_web
-- ------------------------------------------------------
-- Server version	5.6.34-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assetindexdata_sessionId_volumeId_idx` (`sessionId`,`volumeId`),
  KEY `assetindexdata_volumeId_idx` (`volumeId`),
  CONSTRAINT `assetindexdata_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `assets_filename_folderId_unq_idx` (`filename`,`folderId`),
  KEY `assets_folderId_idx` (`folderId`),
  KEY `assets_volumeId_idx` (`volumeId`),
  CONSTRAINT `assets_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assettransformindex`
--

DROP TABLE IF EXISTS `assettransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assettransformindex_volumeId_assetId_location_idx` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assettransforms`
--

DROP TABLE IF EXISTS `assettransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categories_groupId_idx` (`groupId`),
  CONSTRAINT `categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorygroups_name_unq_idx` (`name`),
  UNIQUE KEY `categorygroups_handle_unq_idx` (`handle`),
  KEY `categorygroups_structureId_idx` (`structureId`),
  KEY `categorygroups_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorygroups_sites_groupId_siteId_unq_idx` (`groupId`,`siteId`),
  KEY `categorygroups_sites_siteId_idx` (`siteId`),
  CONSTRAINT `categorygroups_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categorygroups_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_tagline` text,
  `field_body` text,
  `field_heading` text,
  `field_supplemental` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `content_siteId_idx` (`siteId`),
  KEY `content_title_idx` (`title`),
  CONSTRAINT `content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `content_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craftidtokens_userId_fk` (`userId`),
  CONSTRAINT `craftidtokens_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB AUTO_INCREMENT=340 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementindexsettings`
--

DROP TABLE IF EXISTS `elementindexsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `elements_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `elements_type_idx` (`type`),
  KEY `elements_enabled_idx` (`enabled`),
  KEY `elements_archived_dateCreated_idx` (`archived`,`dateCreated`),
  CONSTRAINT `elements_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elements_sites_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  UNIQUE KEY `elements_sites_uri_siteId_unq_idx` (`uri`,`siteId`),
  KEY `elements_sites_siteId_idx` (`siteId`),
  KEY `elements_sites_slug_siteId_idx` (`slug`,`siteId`),
  KEY `elements_sites_enabled_idx` (`enabled`),
  CONSTRAINT `elements_sites_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entries_postDate_idx` (`postDate`),
  KEY `entries_expiryDate_idx` (`expiryDate`),
  KEY `entries_authorId_idx` (`authorId`),
  KEY `entries_sectionId_idx` (`sectionId`),
  KEY `entries_typeId_idx` (`typeId`),
  CONSTRAINT `entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrydrafts`
--

DROP TABLE IF EXISTS `entrydrafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrydrafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrydrafts_sectionId_idx` (`sectionId`),
  KEY `entrydrafts_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `entrydrafts_siteId_idx` (`siteId`),
  KEY `entrydrafts_creatorId_idx` (`creatorId`),
  CONSTRAINT `entrydrafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleLabel` varchar(255) DEFAULT 'Title',
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `entrytypes_name_sectionId_unq_idx` (`name`,`sectionId`),
  UNIQUE KEY `entrytypes_handle_sectionId_unq_idx` (`handle`,`sectionId`),
  KEY `entrytypes_sectionId_idx` (`sectionId`),
  KEY `entrytypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entryversions`
--

DROP TABLE IF EXISTS `entryversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entryversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `siteId` int(11) NOT NULL,
  `num` smallint(6) unsigned NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entryversions_sectionId_idx` (`sectionId`),
  KEY `entryversions_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `entryversions_siteId_idx` (`siteId`),
  KEY `entryversions_creatorId_idx` (`creatorId`),
  CONSTRAINT `entryversions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entryversions_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entryversions_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entryversions_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayoutfields_tabId_idx` (`tabId`),
  KEY `fieldlayoutfields_fieldId_idx` (`fieldId`),
  CONSTRAINT `fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouts_type_idx` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayouttabs_layoutId_idx` (`layoutId`),
  CONSTRAINT `fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `instructions` text,
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `fields_groupId_idx` (`groupId`),
  KEY `fields_context_idx` (`context`),
  CONSTRAINT `fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `globalsets_name_unq_idx` (`name`),
  UNIQUE KEY `globalsets_handle_unq_idx` (`handle`),
  KEY `globalsets_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `edition` smallint(6) unsigned NOT NULL,
  `timezone` varchar(30) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `matrixblocks_ownerId_idx` (`ownerId`),
  KEY `matrixblocks_fieldId_idx` (`fieldId`),
  KEY `matrixblocks_typeId_idx` (`typeId`),
  KEY `matrixblocks_sortOrder_idx` (`sortOrder`),
  KEY `matrixblocks_ownerSiteId_idx` (`ownerSiteId`),
  CONSTRAINT `matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `matrixblocktypes_fieldId_idx` (`fieldId`),
  KEY `matrixblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_contentmatrix`
--

DROP TABLE IF EXISTS `matrixcontent_contentmatrix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_contentmatrix` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_textBlock_style` varchar(255) DEFAULT NULL,
  `field_textBlock_heading` text,
  `field_textBlock_paragraph` text,
  `field_textBlock_externalLink` text,
  `field_textBlock_components` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_contentmatrix_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_contentmatrix_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_contentmatrix_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_contentmatrix_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_socialmedia`
--

DROP TABLE IF EXISTS `matrixcontent_socialmedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_socialmedia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_socialMediaBlock_socialName` varchar(255) DEFAULT NULL,
  `field_socialMediaBlock_address` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_socialmedia_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_socialmedia_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_socialmedia_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_socialmedia_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `type` enum('app','plugin','content') NOT NULL DEFAULT 'app',
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `migrations_pluginId_idx` (`pluginId`),
  KEY `migrations_type_pluginId_idx` (`type`,`pluginId`),
  CONSTRAINT `migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKey` char(24) DEFAULT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','unknown') NOT NULL DEFAULT 'unknown',
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `settings` text,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plugins_handle_unq_idx` (`handle`),
  KEY `plugins_enabled_idx` (`enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `queue_fail_timeUpdated_timePushed_idx` (`fail`,`timeUpdated`,`timePushed`),
  KEY `queue_fail_timeUpdated_delay_idx` (`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `relations_fieldId_sourceId_sourceSiteId_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `relations_sourceId_idx` (`sourceId`),
  KEY `relations_targetId_idx` (`targetId`),
  KEY `relations_sourceSiteId_idx` (`sourceSiteId`),
  CONSTRAINT `relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `routes`
--

DROP TABLE IF EXISTS `routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) DEFAULT NULL,
  `uriParts` varchar(255) NOT NULL,
  `uriPattern` varchar(255) NOT NULL,
  `template` varchar(500) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `routes_uriPattern_idx` (`uriPattern`),
  KEY `routes_siteId_idx` (`siteId`),
  CONSTRAINT `routes_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sections_handle_unq_idx` (`handle`),
  UNIQUE KEY `sections_name_unq_idx` (`name`),
  KEY `sections_structureId_idx` (`structureId`),
  CONSTRAINT `sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sections_sites_sectionId_siteId_unq_idx` (`sectionId`,`siteId`),
  KEY `sections_sites_siteId_idx` (`siteId`),
  CONSTRAINT `sections_sites_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sections_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sessions_uid_idx` (`uid`),
  KEY `sessions_token_idx` (`token`),
  KEY `sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `sessions_userId_idx` (`userId`),
  CONSTRAINT `sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sitegroups_name_unq_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sites_handle_unq_idx` (`handle`),
  KEY `sites_sortOrder_idx` (`sortOrder`),
  KEY `sites_groupId_fk` (`groupId`),
  CONSTRAINT `sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `structureelements_root_idx` (`root`),
  KEY `structureelements_lft_idx` (`lft`),
  KEY `structureelements_rgt_idx` (`rgt`),
  KEY `structureelements_level_idx` (`level`),
  KEY `structureelements_elementId_idx` (`elementId`),
  CONSTRAINT `structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `systemmessages_key_language_unq_idx` (`key`,`language`),
  KEY `systemmessages_language_idx` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemsettings`
--

DROP TABLE IF EXISTS `systemsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(15) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `systemsettings_category_unq_idx` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `taggroups_name_unq_idx` (`name`),
  UNIQUE KEY `taggroups_handle_unq_idx` (`handle`),
  KEY `taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tags_groupId_idx` (`groupId`),
  CONSTRAINT `tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tags_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecacheelements`
--

DROP TABLE IF EXISTS `templatecacheelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `templatecacheelements_cacheId_idx` (`cacheId`),
  KEY `templatecacheelements_elementId_idx` (`elementId`),
  CONSTRAINT `templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecachequeries`
--

DROP TABLE IF EXISTS `templatecachequeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecachequeries_cacheId_idx` (`cacheId`),
  KEY `templatecachequeries_type_idx` (`type`),
  CONSTRAINT `templatecachequeries_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecaches`
--

DROP TABLE IF EXISTS `templatecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_path_idx` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_idx` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `templatecaches_siteId_idx` (`siteId`),
  CONSTRAINT `templatecaches_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` smallint(6) unsigned DEFAULT NULL,
  `usageCount` smallint(6) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tokens_token_unq_idx` (`token`),
  KEY `tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_handle_unq_idx` (`handle`),
  UNIQUE KEY `usergroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `usergroups_users_userId_idx` (`userId`),
  CONSTRAINT `usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `userpermissions_usergroups_groupId_idx` (`groupId`),
  CONSTRAINT `userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `userpermissions_users_userId_idx` (`userId`),
  CONSTRAINT `userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `userpreferences_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `client` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` smallint(6) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unq_idx` (`username`),
  UNIQUE KEY `users_email_unq_idx` (`email`),
  KEY `users_uid_idx` (`uid`),
  KEY `users_verificationCode_idx` (`verificationCode`),
  KEY `users_photoId_fk` (`photoId`),
  CONSTRAINT `users_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_photoId_fk` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `volumefolders_name_parentId_volumeId_unq_idx` (`name`,`parentId`,`volumeId`),
  KEY `volumefolders_parentId_idx` (`parentId`),
  KEY `volumefolders_volumeId_idx` (`volumeId`),
  CONSTRAINT `volumefolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `volumefolders_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `settings` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `volumes_name_unq_idx` (`name`),
  UNIQUE KEY `volumes_handle_unq_idx` (`handle`),
  KEY `volumes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `volumes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(1) NOT NULL DEFAULT '0',
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `widgets_userId_idx` (`userId`),
  CONSTRAINT `widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'uxakron_web'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-29 21:30:47
-- MySQL dump 10.13  Distrib 5.5.58, for debian-linux-gnu (x86_64)
--
-- Host: db.uxakron.com    Database: uxakron_web
-- ------------------------------------------------------
-- Server version	5.6.34-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (3,1,1,'ux.svg','image',288,288,3306,NULL,'2017-12-29 02:45:16','2017-12-29 02:45:16','2017-12-29 02:45:20','2305a8c9-ab3a-48f9-8b86-44a8d4085130'),(6,1,1,'network.svg','image',423,364,4838,NULL,'2017-12-30 05:14:53','2017-12-30 05:14:54','2017-12-30 05:14:54','f24b9043-81ef-4757-adc4-4ce9857964ba'),(8,1,1,'mail.svg','image',54,37,1581,NULL,'2017-12-30 05:17:03','2017-12-30 05:17:03','2017-12-30 05:17:03','8058b044-0f85-4c0a-8ed3-cb7dcad6e4c1');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assettransforms`
--

LOCK TABLES `assettransforms` WRITE;
/*!40000 ALTER TABLE `assettransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assettransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,NULL,'2017-12-29 00:56:40','2017-12-29 02:47:39','71578a51-03a6-43ec-82c7-e0cb296846c2',NULL,NULL,NULL,NULL),(2,2,1,NULL,'2017-12-29 02:43:55','2017-12-29 02:45:32','53904886-4fd8-4274-93c0-6904e45fd3e5','A User Experience Community in Northeast Ohio',NULL,NULL,NULL),(3,3,1,'Ux','2017-12-29 02:45:16','2017-12-29 02:45:20','1ecaa858-37d8-483b-ba7c-e6e398e0b290',NULL,NULL,NULL,NULL),(4,4,1,'Home','2017-12-29 03:12:21','2017-12-30 05:17:26','3e5addad-a57b-4802-99d9-45cbbe77eb49',NULL,'<p>UX Akron is a user experience (UX) meetup community in Northeast Ohio, primarily serving members from Akron, Canton, Youngstown and Kent. Anyone is welcome - from students and those new to UX to seasoned professionals. Join our next meeting to get a taste of the great events we offer all year.</p>',NULL,NULL),(5,5,1,NULL,'2017-12-30 05:10:11','2017-12-30 05:26:39','c0063e7c-ab6f-4575-b739-c0d30e1c4c05',NULL,NULL,'Get in Touch','UX Akron.  All Rights Reserved.'),(6,6,1,'Network','2017-12-30 05:14:54','2017-12-30 05:14:54','370fa27e-6cbe-41cb-ba2b-cd3044f6bf3c',NULL,NULL,NULL,NULL),(7,8,1,'Mail','2017-12-30 05:17:03','2017-12-30 05:17:03','b8ba3322-3bcb-45a2-8e0d-f6974c188f9b',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `deprecationerrors` VALUES (1,'ElementQuery::getIterator()','/home/uxakron_jadmin/templates/_includes/_header.html:4','2017-12-30 05:28:56','/home/uxakron_jadmin/templates/_includes/_header.html',4,'Looping through element queries directly has been deprecated. Use the all() function to fetch the query results before looping over them.','[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":397,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\AssetQuery\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/21/217757c546088ee34e56aa5a1d8c4ee93ebaa889d9857f07a242b6dafca631b4.php\",\"line\":26,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_6ea426a5193a9c1544844cae3180171bcc5abfd3b35ecd5f4c31ad2b4c99194d\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_6ea426a5193a9c1544844cae3180171bcc5abfd3b35ecd5f4c31ad2b4c99194d\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_6ea426a5193a9c1544844cae3180171bcc5abfd3b35ecd5f4c31ad2b4c99194d\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_6ea426a5193a9c1544844cae3180171bcc5abfd3b35ecd5f4c31ad2b4c99194d\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_6ea426a5193a9c1544844cae3180171bcc5abfd3b35ecd5f4c31ad2b4c99194d\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_6ea426a5193a9c1544844cae3180171bcc5abfd3b35ecd5f4c31ad2b4c99194d\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/e6/e69ffea9d89481a78ad86f71f95a49674c714d4c25f1451514faedcec71a0d52.php\",\"line\":35,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/3e/3e901ec4b668123f8f94a060a2890d1f604bbb3612bf94dd54b1703b6fd19d46.php\",\"line\":24,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":374,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Environment.php\",\"line\":289,\"class\":\"Twig_Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/View.php\",\"line\":292,\"class\":\"Twig_Environment\",\"method\":\"render\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/View.php\",\"line\":340,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Controller.php\",\"line\":121,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":79,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Controller.php\",\"line\":157,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Controller.php\",\"line\":80,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Module.php\",\"line\":528,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Application.php\",\"line\":242,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/web/Application.php\",\"line\":103,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Application.php\",\"line\":207,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Application.php\",\"line\":386,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/uxakron.com/index.php\",\"line\":21,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]','2017-12-30 05:28:56','2017-12-30 05:28:56','4f3a9876-a2ef-41f1-a43a-51e50b1a8040'),(293,'ElementQuery::getIterator()','/home/uxakron_jadmin/templates/_includes/_contentBlock.html:1','2017-12-30 05:28:56','/home/uxakron_jadmin/templates/_includes/_contentBlock.html',1,'Looping through element queries directly has been deprecated. Use the all() function to fetch the query results before looping over them.','[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":397,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\MatrixBlockQuery\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/af/af5b02e65cb86acedb8ba33e1d5e28f65543b5116ae74f3718c6e1a549c96ef4.php\",\"line\":34,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/3e/3e901ec4b668123f8f94a060a2890d1f604bbb3612bf94dd54b1703b6fd19d46.php\",\"line\":34,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":188,\"class\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/e6/e69ffea9d89481a78ad86f71f95a49674c714d4c25f1451514faedcec71a0d52.php\",\"line\":40,\"class\":\"Twig_Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/3e/3e901ec4b668123f8f94a060a2890d1f604bbb3612bf94dd54b1703b6fd19d46.php\",\"line\":24,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":374,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Environment.php\",\"line\":289,\"class\":\"Twig_Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/View.php\",\"line\":292,\"class\":\"Twig_Environment\",\"method\":\"render\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/View.php\",\"line\":340,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Controller.php\",\"line\":121,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":79,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Controller.php\",\"line\":157,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Controller.php\",\"line\":80,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Module.php\",\"line\":528,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Application.php\",\"line\":242,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/web/Application.php\",\"line\":103,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Application.php\",\"line\":207,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Application.php\",\"line\":386,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/uxakron.com/index.php\",\"line\":21,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]','2017-12-30 05:28:56','2017-12-30 05:28:56','b12e3c2f-7c06-49a2-a6ec-669b13de074e'),(294,'ElementQuery::getIterator()','/home/uxakron_jadmin/templates/_includes/_footer.html:7','2017-12-30 05:28:56','/home/uxakron_jadmin/templates/_includes/_footer.html',7,'Looping through element queries directly has been deprecated. Use the all() function to fetch the query results before looping over them.','[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":397,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\MatrixBlockQuery\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/9f/9faff0f0bcbd9f59a0760c324c57e9b3adb0a728b800dee8c99d2e305a4549d1.php\",\"line\":29,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_ce90f37e05829e4b4ea42479a870c069fd53f31aeca18fa19242f103fab2e19c\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_ce90f37e05829e4b4ea42479a870c069fd53f31aeca18fa19242f103fab2e19c\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_ce90f37e05829e4b4ea42479a870c069fd53f31aeca18fa19242f103fab2e19c\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_ce90f37e05829e4b4ea42479a870c069fd53f31aeca18fa19242f103fab2e19c\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_ce90f37e05829e4b4ea42479a870c069fd53f31aeca18fa19242f103fab2e19c\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_ce90f37e05829e4b4ea42479a870c069fd53f31aeca18fa19242f103fab2e19c\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/e6/e69ffea9d89481a78ad86f71f95a49674c714d4c25f1451514faedcec71a0d52.php\",\"line\":45,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/3e/3e901ec4b668123f8f94a060a2890d1f604bbb3612bf94dd54b1703b6fd19d46.php\",\"line\":24,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":374,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Environment.php\",\"line\":289,\"class\":\"Twig_Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/View.php\",\"line\":292,\"class\":\"Twig_Environment\",\"method\":\"render\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/View.php\",\"line\":340,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Controller.php\",\"line\":121,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":79,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Controller.php\",\"line\":157,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Controller.php\",\"line\":80,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Module.php\",\"line\":528,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Application.php\",\"line\":242,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/web/Application.php\",\"line\":103,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Application.php\",\"line\":207,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Application.php\",\"line\":386,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/uxakron.com/index.php\",\"line\":21,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]','2017-12-30 05:28:56','2017-12-30 05:28:56','08c46c3c-1a1d-4b38-8338-047f6b988185'),(300,'ElementQuery::getIterator()','/home/uxakron_jadmin/templates/_includes/_contentBlock.html:13','2017-12-30 05:28:56','/home/uxakron_jadmin/templates/_includes/_contentBlock.html',13,'Looping through element queries directly has been deprecated. Use the all() function to fetch the query results before looping over them.','[{\"objectClass\":\"craft\\\\services\\\\Deprecator\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/elements/db/ElementQuery.php\",\"line\":397,\"class\":\"craft\\\\services\\\\Deprecator\",\"method\":\"log\",\"args\":\"\\\"ElementQuery::getIterator()\\\", \\\"Looping through element queries directly has been deprecated. Us...\\\"\"},{\"objectClass\":\"craft\\\\elements\\\\db\\\\AssetQuery\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/af/af5b02e65cb86acedb8ba33e1d5e28f65543b5116ae74f3718c6e1a549c96ef4.php\",\"line\":66,\"class\":\"craft\\\\elements\\\\db\\\\ElementQuery\",\"method\":\"getIterator\",\"args\":null},{\"objectClass\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], []\"},{\"objectClass\":\"__TwigTemplate_00ebf8906878bb8b66b952d46eab7dbd694de849d5df5d8ef1860ce4416d3637\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/3e/3e901ec4b668123f8f94a060a2890d1f604bbb3612bf94dd54b1703b6fd19d46.php\",\"line\":34,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":188,\"class\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"method\":\"block_content\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/e6/e69ffea9d89481a78ad86f71f95a49674c714d4c25f1451514faedcec71a0d52.php\",\"line\":40,\"class\":\"Twig_Template\",\"method\":\"displayBlock\",\"args\":\"\\\"content\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_1fe76d77357452e76a59a592bf98376876a20fa8ef3e5f18e0c06af1c3f04eee\",\"file\":\"/home/uxakron_jadmin/storage/runtime/compiled_templates/3e/3e901ec4b668123f8f94a060a2890d1f604bbb3612bf94dd54b1703b6fd19d46.php\",\"line\":24,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":389,\"class\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"method\":\"doDisplay\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":51,\"class\":\"Twig_Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":366,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"displayWithErrorHandling\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry], \\\"view\\\" => craft\\\\web\\\\View, \\\"SORT_ASC\\\" => 4, ...], [\\\"content\\\" => [__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1, \\\"block_content\\\"]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/twig/Template.php\",\"line\":32,\"class\":\"Twig_Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]], []\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Template.php\",\"line\":374,\"class\":\"craft\\\\web\\\\twig\\\\Template\",\"method\":\"display\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"__TwigTemplate_b3d8d3f6eba365afb0e56ce739e841b4a2b49d2b4a2f1918bf87289e8fb5c2c1\",\"file\":\"/home/uxakron_jadmin/vendor/twig/twig/lib/Twig/Environment.php\",\"line\":289,\"class\":\"Twig_Template\",\"method\":\"render\",\"args\":\"[\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\twig\\\\Environment\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/View.php\",\"line\":292,\"class\":\"Twig_Environment\",\"method\":\"render\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/View.php\",\"line\":340,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\View\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Controller.php\",\"line\":121,\"class\":\"craft\\\\web\\\\View\",\"method\":\"renderPageTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/controllers/TemplatesController.php\",\"line\":79,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"renderTemplate\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":null,\"line\":null,\"class\":\"craft\\\\controllers\\\\TemplatesController\",\"method\":\"actionRender\",\"args\":\"\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry, \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":null,\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/InlineAction.php\",\"line\":57,\"class\":null,\"method\":\"call_user_func_array\",\"args\":\"[craft\\\\controllers\\\\TemplatesController, \\\"actionRender\\\"], [\\\"index.html\\\", [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"yii\\\\base\\\\InlineAction\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Controller.php\",\"line\":157,\"class\":\"yii\\\\base\\\\InlineAction\",\"method\":\"runWithParams\",\"args\":\"[\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Controller.php\",\"line\":80,\"class\":\"yii\\\\base\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\controllers\\\\TemplatesController\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Module.php\",\"line\":528,\"class\":\"craft\\\\web\\\\Controller\",\"method\":\"runAction\",\"args\":\"\\\"render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Application.php\",\"line\":242,\"class\":\"yii\\\\base\\\\Module\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/web/Application.php\",\"line\":103,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"runAction\",\"args\":\"\\\"templates/render\\\", [\\\"template\\\" => \\\"index.html\\\", \\\"variables\\\" => [\\\"entry\\\" => craft\\\\elements\\\\Entry]]\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/craftcms/cms/src/web/Application.php\",\"line\":207,\"class\":\"yii\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/vendor/yiisoft/yii2/base/Application.php\",\"line\":386,\"class\":\"craft\\\\web\\\\Application\",\"method\":\"handleRequest\",\"args\":\"craft\\\\web\\\\Request\"},{\"objectClass\":\"craft\\\\web\\\\Application\",\"file\":\"/home/uxakron_jadmin/uxakron.com/index.php\",\"line\":21,\"class\":\"yii\\\\base\\\\Application\",\"method\":\"run\",\"args\":null}]','2017-12-30 05:28:56','2017-12-30 05:28:56','472f133f-fc98-4929-b384-5ebfcaa5f36b');
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementindexsettings`
--

LOCK TABLES `elementindexsettings` WRITE;
/*!40000 ALTER TABLE `elementindexsettings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elementindexsettings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,'craft\\elements\\User',1,0,'2017-12-29 00:56:40','2017-12-29 02:47:39','3e05cb8c-25a0-4f43-aa24-fdf703b14553'),(2,2,'craft\\elements\\GlobalSet',1,0,'2017-12-29 02:43:55','2017-12-29 02:45:32','59ce193f-476c-4570-be63-0cf955992c3c'),(3,1,'craft\\elements\\Asset',1,0,'2017-12-29 02:45:16','2017-12-29 02:45:20','b68b423e-1e20-4199-9178-1040fdfc2c8f'),(4,3,'craft\\elements\\Entry',1,0,'2017-12-29 03:12:21','2017-12-30 05:17:26','00647310-6be5-4864-a7d9-0e19ce99c001'),(5,6,'craft\\elements\\GlobalSet',1,0,'2017-12-30 05:10:11','2017-12-30 05:26:39','b3c94a16-854c-4a28-9e02-a7c29a427b8d'),(6,1,'craft\\elements\\Asset',1,0,'2017-12-30 05:14:54','2017-12-30 05:14:54','d2c66656-8446-457c-8e9f-dabb52fe1a7d'),(7,4,'craft\\elements\\MatrixBlock',1,0,'2017-12-30 05:14:58','2017-12-30 05:17:26','fa52da8a-d0e2-458d-9d4b-e37046d11c42'),(8,1,'craft\\elements\\Asset',1,0,'2017-12-30 05:17:03','2017-12-30 05:17:03','7ca8d82d-6af9-492a-ba53-eea2f63ce759'),(9,4,'craft\\elements\\MatrixBlock',1,0,'2017-12-30 05:17:26','2017-12-30 05:17:26','906f2850-fc99-4379-b027-b999ab11a530'),(10,4,'craft\\elements\\MatrixBlock',1,0,'2017-12-30 05:17:26','2017-12-30 05:17:26','8881f796-702e-4062-a938-3137c1dd853a'),(11,5,'craft\\elements\\MatrixBlock',1,0,'2017-12-30 05:26:39','2017-12-30 05:26:39','1daa8576-9425-46a9-80dd-5666f59c9cfd'),(12,5,'craft\\elements\\MatrixBlock',1,0,'2017-12-30 05:26:39','2017-12-30 05:26:39','aa23bf6e-c164-45d0-b8a5-6310c0be3248'),(13,5,'craft\\elements\\MatrixBlock',1,0,'2017-12-30 05:26:39','2017-12-30 05:26:39','e6329afb-8c94-42de-8c9c-ed3dd6cdf93d'),(14,5,'craft\\elements\\MatrixBlock',1,0,'2017-12-30 05:26:39','2017-12-30 05:26:39','62dca250-1e46-4dde-b496-527a0c54f08a');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2017-12-29 00:56:40','2017-12-29 02:47:39','9f2558dd-400a-44fa-bd9d-04234e697cb2'),(2,2,1,NULL,NULL,1,'2017-12-29 02:43:55','2017-12-29 02:45:32','9e48269d-c9e4-416b-bb4a-a16c432d5efe'),(3,3,1,NULL,NULL,1,'2017-12-29 02:45:16','2017-12-29 02:45:20','83a5b1fd-0898-4049-843b-afb62d95acc1'),(4,4,1,'home','__home__',1,'2017-12-29 03:12:21','2017-12-30 05:17:26','32f2dba9-0d18-4363-aa7b-15b3cb715fc1'),(5,5,1,NULL,NULL,1,'2017-12-30 05:10:11','2017-12-30 05:26:39','1dc09102-28ca-4c67-ab04-aee26480f657'),(6,6,1,NULL,NULL,1,'2017-12-30 05:14:54','2017-12-30 05:14:54','b44dad89-f002-4dd6-b4bb-789fbacb4f3e'),(7,7,1,NULL,NULL,1,'2017-12-30 05:14:58','2017-12-30 05:17:26','b3c0d90a-7275-41a6-84fd-0a201fa08f86'),(8,8,1,NULL,NULL,1,'2017-12-30 05:17:03','2017-12-30 05:17:03','66db6666-a379-43da-8205-f9db5379c52c'),(9,9,1,NULL,NULL,1,'2017-12-30 05:17:26','2017-12-30 05:17:26','adf841e5-31f2-4506-b4a4-5f46a9291fe3'),(10,10,1,NULL,NULL,1,'2017-12-30 05:17:26','2017-12-30 05:17:26','66b898f2-17d6-4bb8-a241-25daf0ba9a7a'),(11,11,1,NULL,NULL,1,'2017-12-30 05:26:39','2017-12-30 05:26:39','1623527a-1d70-4d51-8f84-5b5589cd80db'),(12,12,1,NULL,NULL,1,'2017-12-30 05:26:39','2017-12-30 05:26:39','36dd5b8a-b5cc-4c11-a46c-be4494034977'),(13,13,1,NULL,NULL,1,'2017-12-30 05:26:39','2017-12-30 05:26:39','5b1901be-ce5b-4c07-b09d-16dc443c2523'),(14,14,1,NULL,NULL,1,'2017-12-30 05:26:39','2017-12-30 05:26:39','58313631-acc2-45d5-b5ab-6a23cdaaa51d');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (4,1,1,NULL,'2017-12-29 03:12:21',NULL,'2017-12-29 03:12:21','2017-12-30 05:17:26','8a795f71-da79-48f9-91d0-a26f0bbccc53');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrydrafts`
--

LOCK TABLES `entrydrafts` WRITE;
/*!40000 ALTER TABLE `entrydrafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `entrydrafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,3,'Home','home',0,NULL,'{section.name|raw}',1,'2017-12-29 03:12:21','2017-12-30 05:09:26','c04c0a9d-e5fa-4177-9fd2-41f5eb934c1c');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entryversions`
--

LOCK TABLES `entryversions` WRITE;
/*!40000 ALTER TABLE `entryversions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entryversions` VALUES (1,4,1,1,1,1,'Revision from Dec 28, 2017, 7:12:35 PM','{\"typeId\":\"1\",\"authorId\":\"1\",\"title\":\"Home\",\"slug\":\"home\",\"postDate\":1514517141,\"expiryDate\":null,\"enabled\":\"1\",\"newParentId\":null,\"fields\":[]}','2017-12-29 03:12:42','2017-12-29 03:12:42','99a839fd-06f1-4e02-8acf-5bc80407e67d'),(2,4,1,1,1,2,'','{\"typeId\":\"1\",\"authorId\":null,\"title\":\"Home\",\"slug\":\"home\",\"postDate\":1514517141,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"3\":\"<p>Testing.</p>\"}}','2017-12-29 03:12:42','2017-12-29 03:12:42','8a48e40c-5e9f-45e3-a8f9-f95361d8fdef'),(3,4,1,1,1,3,'','{\"typeId\":\"1\",\"authorId\":null,\"title\":\"Home\",\"slug\":\"home\",\"postDate\":1514517141,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"3\":\"<p>UX Akron is a user experience (UX) meetup community in Northeast Ohio, primarily serving members from Akron, Canton, Youngstown and Kent. Anyone is welcome - from students and those new to UX to seasoned professionals. Join our next meeting to get a taste of the great events we offer all year.</p>\"}}','2017-12-29 03:12:56','2017-12-29 03:12:56','2bcc5fc1-6fc8-45a4-b1c5-2ee2606a6b52'),(4,4,1,1,1,4,'','{\"typeId\":\"1\",\"authorId\":null,\"title\":\"Home\",\"slug\":\"home\",\"postDate\":1514517141,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"3\":\"<p>UX Akron is a user experience (UX) meetup community in Northeast Ohio, primarily serving members from Akron, Canton, Youngstown and Kent. Anyone is welcome - from students and those new to UX to seasoned professionals. Join our next meeting to get a taste of the great events we offer all year.</p>\"}}','2017-12-29 03:13:06','2017-12-29 03:13:06','e4f3e727-c813-4196-b685-ec18e6c6445a'),(5,4,1,1,1,5,'','{\"typeId\":\"1\",\"authorId\":null,\"title\":\"Home\",\"slug\":\"home\",\"postDate\":1514517141,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"4\":{\"7\":{\"type\":\"textBlock\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"icon\":[\"6\"],\"style\":\"dark\",\"heading\":\"Who We Are\",\"paragraph\":\"<p>UX Akron is a user experience (UX) meetup community in Northeast Ohio, primarily serving members from Akron, Canton, Youngstown and Kent. Anyone is welcome - from students and those new to UX to seasoned professionals. Join our next meeting to get a taste of the great events we offer all year.</p>\",\"externalLink\":null,\"components\":\"[]\"}}}}}','2017-12-30 05:14:58','2017-12-30 05:14:58','563ecd74-a420-4996-a626-203fef11cebb'),(6,4,1,1,1,6,'','{\"typeId\":\"1\",\"authorId\":null,\"title\":\"Home\",\"slug\":\"home\",\"postDate\":1514517141,\"expiryDate\":null,\"enabled\":true,\"newParentId\":null,\"fields\":{\"4\":{\"7\":{\"type\":\"textBlock\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"icon\":[\"6\"],\"style\":\"dark\",\"heading\":\"Who We Are\",\"paragraph\":\"<p>UX Akron is a user experience (UX) meetup community in Northeast Ohio, primarily serving members from Akron, Canton, Youngstown and Kent. Anyone is welcome - from students and those new to UX to seasoned professionals. Join our next meeting to get a taste of the great events we offer all year.</p>\",\"externalLink\":null,\"components\":\"[]\"}},\"9\":{\"type\":\"textBlock\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"icon\":[],\"style\":\"light\",\"heading\":\"Attend an Event\",\"paragraph\":\"<p>Our monthly events are open to anyone.  Take a look at our list of upcoming meetups and register for one that interests you.  Most events are free of charge.</p>\",\"externalLink\":[{\"col1\":\"See More Events\",\"col2\":\"http://www.meetup.com/uxakron/\"}],\"components\":\"[\\\"eventsList\\\"]\"}},\"10\":{\"type\":\"textBlock\",\"enabled\":true,\"collapsed\":false,\"fields\":{\"icon\":[\"8\"],\"style\":\"dark\",\"heading\":\"Mailing List\",\"paragraph\":\"<p>Interested in future events? Enter your information here and we’ll send you information about upcoming UX meetups.</p>\",\"externalLink\":null,\"components\":\"[\\\"contactForm\\\"]\"}}}}}','2017-12-30 05:17:27','2017-12-30 05:17:27','0902ce25-9676-4f33-82ff-070b091948e9');
/*!40000 ALTER TABLE `entryversions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2017-12-29 00:56:40','2017-12-29 00:56:40','f565f049-ed4b-497c-ad31-017e5109f004');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayoutfields` VALUES (3,2,2,1,0,1,'2017-12-29 02:44:44','2017-12-29 02:44:44','35c7669d-7719-481f-a2b5-9a6de4a8d764'),(4,2,2,2,0,2,'2017-12-29 02:44:44','2017-12-29 02:44:44','a1b8f6a4-e58d-435b-aea7-1cbfcee04c5c'),(6,4,4,5,0,1,'2017-12-30 05:05:52','2017-12-30 05:05:52','320af5d2-fa70-41fa-9646-2b680b3d6e3e'),(7,4,4,6,0,2,'2017-12-30 05:05:52','2017-12-30 05:05:52','33703961-7549-4543-b741-428654a30b5e'),(8,4,4,7,0,3,'2017-12-30 05:05:52','2017-12-30 05:05:52','f3f4d807-8f31-4089-af3c-9c2f84bb97cd'),(9,4,4,8,0,4,'2017-12-30 05:05:52','2017-12-30 05:05:52','d1014e4a-9e04-4311-a0fb-6680ea68cbaf'),(10,4,4,9,0,5,'2017-12-30 05:05:52','2017-12-30 05:05:52','509b24cd-dc14-47a8-b225-72c8b5b5b557'),(11,4,4,10,0,6,'2017-12-30 05:05:52','2017-12-30 05:05:52','f708b825-f7ce-42fc-b8d3-aeced82067e2'),(13,5,6,13,0,1,'2017-12-30 05:08:00','2017-12-30 05:08:00','6cbf3fe9-b026-4522-84f8-e3f82cba8fd2'),(14,5,6,14,0,2,'2017-12-30 05:08:00','2017-12-30 05:08:00','6a6d4c83-86c6-4ad4-a906-9cb18f0ae252'),(15,3,7,4,0,1,'2017-12-30 05:09:26','2017-12-30 05:09:26','d7edf40e-3dbb-4d8b-bc07-6e9df1e689c1'),(16,6,8,11,0,1,'2017-12-30 05:10:33','2017-12-30 05:10:33','36bd0690-c20a-46d4-9478-1f620a1eb3ab'),(17,6,8,12,0,2,'2017-12-30 05:10:33','2017-12-30 05:10:33','4d85c2a6-d0e6-4938-8050-a64c0d18b917'),(18,6,8,15,0,3,'2017-12-30 05:10:33','2017-12-30 05:10:33','805f2e32-86ab-4ed4-8103-8d50d40a8320');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Asset','2017-12-29 02:43:44','2017-12-29 02:43:44','c2f4a21e-4f41-4285-9b3e-256c69379d06'),(2,'craft\\elements\\GlobalSet','2017-12-29 02:43:55','2017-12-29 02:44:44','7a44ac09-0cd3-490c-9147-d83937ec5135'),(3,'craft\\elements\\Entry','2017-12-29 03:12:21','2017-12-30 05:09:26','79a425eb-8f10-47c8-acb4-4e27e29c194b'),(4,'craft\\elements\\MatrixBlock','2017-12-30 05:05:52','2017-12-30 05:05:52','7cfa9da3-f14b-4e2d-8747-2085a35349b8'),(5,'craft\\elements\\MatrixBlock','2017-12-30 05:07:34','2017-12-30 05:08:00','222d13cb-4ab1-48d7-8ff2-cbe4e267e368'),(6,'craft\\elements\\GlobalSet','2017-12-30 05:10:11','2017-12-30 05:10:33','e68ff2bf-f50c-4e40-80d5-17cf5c8d159d');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouttabs` VALUES (2,2,'Tab 1',1,'2017-12-29 02:44:44','2017-12-29 02:44:44','1bc5d64a-4807-495e-9e78-9dec9ea1a54d'),(4,4,'Content',1,'2017-12-30 05:05:52','2017-12-30 05:05:52','b709a1b1-e4ec-4ab2-a76e-31cb75d7c46b'),(6,5,'Content',1,'2017-12-30 05:08:00','2017-12-30 05:08:00','285cd123-bb4e-4de4-acab-9299509ade51'),(7,3,'Tab 1',1,'2017-12-30 05:09:26','2017-12-30 05:09:26','fff37534-8545-43f3-a5cb-d5ef0c519a2f'),(8,6,'Tab 1',1,'2017-12-30 05:10:33','2017-12-30 05:10:33','1ba2d533-ba53-474f-bc1a-c0e6426f00e7');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,1,'Logo','logo','global','','site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"1\",\"defaultUploadLocationSource\":\"folder:1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"folder:1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"allowedKinds\":null,\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"\",\"selectionLabel\":\"\",\"localizeRelations\":false}','2017-12-29 02:43:05','2017-12-29 02:44:29','3eeb0b27-38d5-4ddd-a300-61e3d43a17b6'),(2,1,'Tagline','tagline','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2017-12-29 02:43:10','2017-12-29 02:43:10','3cd4f1b0-540f-4552-ab97-2c57b2766c70'),(3,1,'Body','body','global','','none',NULL,'craft\\redactor\\Field','{\"redactorConfig\":\"\",\"purifierConfig\":\"\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}','2017-12-29 03:12:02','2017-12-29 03:12:02','af1b2d8d-14c7-423d-a8a1-67257c0bc8b8'),(4,1,'Content','contentMatrix','global','Choose the content blocks you\'d like on this page.','site',NULL,'craft\\fields\\Matrix','{\"maxBlocks\":\"\",\"localizeBlocks\":false}','2017-12-30 05:05:51','2017-12-30 05:05:51','99500df8-a371-4273-b3a5-ebec622b0dd8'),(5,NULL,'Icon','icon','matrixBlockType:1','','site',NULL,'craft\\fields\\Assets','{\"useSingleFolder\":\"\",\"defaultUploadLocationSource\":\"folder:1\",\"defaultUploadLocationSubpath\":\"\",\"singleUploadLocationSource\":\"folder:1\",\"singleUploadLocationSubpath\":\"\",\"restrictFiles\":\"\",\"allowedKinds\":null,\"sources\":\"*\",\"source\":null,\"targetSiteId\":null,\"viewMode\":\"list\",\"limit\":\"\",\"selectionLabel\":\"\",\"localizeRelations\":false}','2017-12-30 05:05:52','2017-12-30 05:05:52','4ef8b46c-77d4-4036-83fc-00a9229517d6'),(6,NULL,'Style','style','matrixBlockType:1','','none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Dark\",\"value\":\"dark\",\"default\":\"1\"},{\"label\":\"Light\",\"value\":\"light\",\"default\":\"\"}]}','2017-12-30 05:05:52','2017-12-30 05:05:52','3fc263cb-57c5-49cf-96ca-7a605b745fb8'),(7,NULL,'Heading','heading','matrixBlockType:1','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2017-12-30 05:05:52','2017-12-30 05:05:52','349de5f0-79a0-45c1-af46-9ad633f4e3a7'),(8,NULL,'Paragraph','paragraph','matrixBlockType:1','','none',NULL,'craft\\redactor\\Field','{\"redactorConfig\":\"\",\"purifierConfig\":\"\",\"cleanupHtml\":\"1\",\"purifyHtml\":\"1\",\"columnType\":\"text\",\"availableVolumes\":\"*\",\"availableTransforms\":\"*\"}','2017-12-30 05:05:52','2017-12-30 05:05:52','21fed7e9-7bc8-4702-ab76-b29bbfb052d6'),(9,NULL,'External Link Button','externalLink','matrixBlockType:1','','none',NULL,'craft\\fields\\Table','{\"columns\":{\"col1\":{\"heading\":\"Link Name\",\"handle\":\"linkName\",\"width\":\"\",\"type\":\"singleline\"},\"col2\":{\"heading\":\"Link URL\",\"handle\":\"linkUrl\",\"width\":\"\",\"type\":\"singleline\"}},\"defaults\":[],\"columnType\":\"text\"}','2017-12-30 05:05:52','2017-12-30 05:05:52','e05e29bc-677b-4ab3-853f-d3a1cc3b1c4e'),(10,NULL,'Additional Components','components','matrixBlockType:1','','none',NULL,'craft\\fields\\Checkboxes','{\"options\":[{\"label\":\"Contact Form\",\"value\":\"contactForm\",\"default\":\"\"},{\"label\":\"Events List\",\"value\":\"eventsList\",\"default\":\"\"}]}','2017-12-30 05:05:52','2017-12-30 05:05:52','7b881fdd-ed1b-4b01-b370-7999d5673824'),(11,1,'Heading','heading','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2017-12-30 05:06:14','2017-12-30 05:06:14','09434edb-98b1-4f17-a2f1-c6a02c1acd96'),(12,1,'Social Media','socialMedia','global','','site',NULL,'craft\\fields\\Matrix','{\"maxBlocks\":\"\",\"localizeBlocks\":false}','2017-12-30 05:07:34','2017-12-30 05:08:00','a712c2a3-733c-4bb1-b611-d42977251106'),(13,NULL,'Social Name','socialName','matrixBlockType:2','','none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Facebook\",\"value\":\"facebook\",\"default\":\"\"},{\"label\":\"@uxakron\",\"value\":\"twitter\",\"default\":\"\"},{\"label\":\"LinkedIn\",\"value\":\"linkedin\",\"default\":\"\"},{\"label\":\"hello@uxakron.com\",\"value\":\"email\",\"default\":\"\"}]}','2017-12-30 05:07:34','2017-12-30 05:08:00','b4aa7c6e-347a-4baa-be7e-daf2e6ea0887'),(14,NULL,'Address','address','matrixBlockType:2','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"http://\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2017-12-30 05:08:00','2017-12-30 05:08:00','d0d265be-48be-48f0-8ee0-b09b604f7776'),(15,1,'Supplemental Text','supplemental','global','','none',NULL,'craft\\fields\\PlainText','{\"placeholder\":\"\",\"multiline\":\"\",\"initialRows\":\"4\",\"charLimit\":\"\",\"columnType\":\"text\"}','2017-12-30 05:08:23','2017-12-30 05:27:48','499c5b65-42a2-4aab-9fe4-c29043026b52');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `globalsets` VALUES (2,'Header','header',2,'2017-12-29 02:43:55','2017-12-29 02:44:44','d493928b-cb7e-4f52-95ad-e708579d10e1'),(5,'Footer','footer',6,'2017-12-30 05:10:11','2017-12-30 05:10:33','8f462696-3464-4c94-b588-a3219641c802');
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'3.0.0-RC3','3.0.76',0,'America/Los_Angeles','UX Akron',1,0,'92ZZmL4evPB4','2017-12-29 00:56:40','2017-12-30 05:27:48','1b653139-3fdc-4599-b824-e06c8389e8ed');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks` VALUES (7,4,NULL,4,1,1,'2017-12-30 05:14:58','2017-12-30 05:17:26','dcf19ede-59be-4c3f-959d-ff5e228e2567'),(9,4,NULL,4,1,2,'2017-12-30 05:17:26','2017-12-30 05:17:26','99ed7c10-9082-4d9f-9145-7c06685e92aa'),(10,4,NULL,4,1,3,'2017-12-30 05:17:26','2017-12-30 05:17:26','560925f1-03a8-44ca-8202-c1532271e8dc'),(11,5,NULL,12,2,1,'2017-12-30 05:26:39','2017-12-30 05:26:39','b916acc7-cedc-4d02-b709-3ee8c46a4587'),(12,5,NULL,12,2,2,'2017-12-30 05:26:39','2017-12-30 05:26:39','6aa79194-4d9a-45ad-afbc-d61b40a00ab7'),(13,5,NULL,12,2,3,'2017-12-30 05:26:39','2017-12-30 05:26:39','dd8ba820-1515-42e8-a0f4-5c530c8a2325'),(14,5,NULL,12,2,4,'2017-12-30 05:26:39','2017-12-30 05:26:39','2312911b-52cf-473d-b721-f18256986ed0');
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocktypes` VALUES (1,4,4,'Block','textBlock',1,'2017-12-30 05:05:52','2017-12-30 05:05:52','58b1c292-1697-4460-8d0e-82ecef59bb7b'),(2,12,5,'Social Media Block','socialMediaBlock',1,'2017-12-30 05:07:34','2017-12-30 05:08:00','4a51d5bb-7f80-4ee3-950c-89e2055a9778');
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_contentmatrix`
--

LOCK TABLES `matrixcontent_contentmatrix` WRITE;
/*!40000 ALTER TABLE `matrixcontent_contentmatrix` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixcontent_contentmatrix` VALUES (1,7,1,'2017-12-30 05:14:58','2017-12-30 05:17:26','38f89fac-c3cf-4787-97f4-c2f2330a13f3','dark','Who We Are','<p>UX Akron is a user experience (UX) meetup community in Northeast Ohio, primarily serving members from Akron, Canton, Youngstown and Kent. Anyone is welcome - from students and those new to UX to seasoned professionals. Join our next meeting to get a taste of the great events we offer all year.</p>',NULL,'[]'),(2,9,1,'2017-12-30 05:17:26','2017-12-30 05:17:26','00e10114-ab64-4970-a52d-ba1e265dac06','light','Attend an Event','<p>Our monthly events are open to anyone.  Take a look at our list of upcoming meetups and register for one that interests you.  Most events are free of charge.</p>','[{\"col1\":\"See More Events\",\"col2\":\"http://www.meetup.com/uxakron/\"}]','[\"eventsList\"]'),(3,10,1,'2017-12-30 05:17:26','2017-12-30 05:17:26','40bc78e5-eeb5-4db9-8bc2-1dbcff7c87fa','dark','Mailing List','<p>Interested in future events? Enter your information here and we’ll send you information about upcoming UX meetups.</p>',NULL,'[\"contactForm\"]');
/*!40000 ALTER TABLE `matrixcontent_contentmatrix` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_socialmedia`
--

LOCK TABLES `matrixcontent_socialmedia` WRITE;
/*!40000 ALTER TABLE `matrixcontent_socialmedia` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixcontent_socialmedia` VALUES (1,11,1,'2017-12-30 05:26:39','2017-12-30 05:26:39','74928462-d8f1-4173-8fe0-32561378cb4e','facebook','http://www.facebook.com/uxakron'),(2,12,1,'2017-12-30 05:26:39','2017-12-30 05:26:39','8b03d4e9-9b1c-4324-b18b-05ca53a0010d','twitter','http://www.twitter.com/uxakron'),(3,13,1,'2017-12-30 05:26:39','2017-12-30 05:26:39','902d7d53-534a-4a95-8257-ab351135bc6b','linkedin','https://www.linkedin.com/company/ux-akron'),(4,14,1,'2017-12-30 05:26:39','2017-12-30 05:26:39','6d5956c1-9b22-460d-b180-a0e67f86e238','email','mailto:hello@uxakron.com');
/*!40000 ALTER TABLE `matrixcontent_socialmedia` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,NULL,'app','Install','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','9320f7b4-86fb-452a-a2f7-f93b7d8c1888'),(2,NULL,'app','m150403_183908_migrations_table_changes','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','c158ea51-375e-43e5-9654-a276a444bedf'),(3,NULL,'app','m150403_184247_plugins_table_changes','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','c79978ea-c876-47f8-ba16-7cf46c6eb9a3'),(4,NULL,'app','m150403_184533_field_version','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','850b3dbc-f970-4663-91be-d52d6e3e0653'),(5,NULL,'app','m150403_184729_type_columns','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','a976ea02-af9f-462b-b90d-1ef226b694f9'),(6,NULL,'app','m150403_185142_volumes','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','10b97e51-a561-4f20-a8ba-622894dfaa08'),(7,NULL,'app','m150428_231346_userpreferences','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','bc03c071-779a-4370-a0ca-60510ad7f2da'),(8,NULL,'app','m150519_150900_fieldversion_conversion','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','fdecb65f-9ec1-42d2-8a0b-64728756ae5c'),(9,NULL,'app','m150617_213829_update_email_settings','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','7a3f8008-43a2-4183-9b2e-6c3c5f010fe6'),(10,NULL,'app','m150721_124739_templatecachequeries','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','edb8c38e-c5a3-42ed-812b-2c674bd1c789'),(11,NULL,'app','m150724_140822_adjust_quality_settings','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','4cb9ae7b-c8c8-4701-9a0f-6474ab86db92'),(12,NULL,'app','m150815_133521_last_login_attempt_ip','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','a86a386e-5ec9-4d7c-8a27-19650f270d2a'),(13,NULL,'app','m151002_095935_volume_cache_settings','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','1e218257-8234-46ef-8112-7882bb44c2eb'),(14,NULL,'app','m151005_142750_volume_s3_storage_settings','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','c675388a-7ef5-4855-8c40-4fb42d379a04'),(15,NULL,'app','m151016_133600_delete_asset_thumbnails','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','cbabb671-1b12-4c34-9b0a-f5bee045181e'),(16,NULL,'app','m151209_000000_move_logo','2017-12-29 00:56:42','2017-12-29 00:56:42','2017-12-29 00:56:42','260279d7-b46b-493d-ae5f-555d9562d9e5'),(17,NULL,'app','m151211_000000_rename_fileId_to_assetId','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','b3da2222-45fa-4ed6-bf13-0d15ce07149c'),(18,NULL,'app','m151215_000000_rename_asset_permissions','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','5614ad24-3f61-42a1-af39-cdb0826db78e'),(19,NULL,'app','m160707_000001_rename_richtext_assetsource_setting','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','220a7bea-f6b1-448d-97e7-1b79802abee8'),(20,NULL,'app','m160708_185142_volume_hasUrls_setting','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','a3d62e54-a751-4368-9583-f3c5c0bacb1b'),(21,NULL,'app','m160714_000000_increase_max_asset_filesize','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','81b9dcc2-144a-451e-83b2-223e61809896'),(22,NULL,'app','m160727_194637_column_cleanup','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','aab54ec7-9c2e-4e56-963f-fe7d07dc2b47'),(23,NULL,'app','m160804_110002_userphotos_to_assets','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','5237a713-d6d5-441e-b466-708bf024f753'),(24,NULL,'app','m160807_144858_sites','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','96f1cfc3-4684-4989-9a24-f7f2b2708851'),(25,NULL,'app','m160829_000000_pending_user_content_cleanup','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','ec826c62-c95e-477a-ae46-5fb959d481d4'),(26,NULL,'app','m160830_000000_asset_index_uri_increase','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','f7f0b7dc-3562-43c2-a5d4-cf39a66d2c10'),(27,NULL,'app','m160912_230520_require_entry_type_id','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','6455bed3-2541-4fdc-ae95-46a5ac946dba'),(28,NULL,'app','m160913_134730_require_matrix_block_type_id','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','609b5a53-847a-4e07-a089-5ec81c030c26'),(29,NULL,'app','m160920_174553_matrixblocks_owner_site_id_nullable','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','ebcbeef6-5390-4873-a7fe-d8813b0cb713'),(30,NULL,'app','m160920_231045_usergroup_handle_title_unique','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','4998b5c4-3102-457c-909d-c5ea17145093'),(31,NULL,'app','m160925_113941_route_uri_parts','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','c490239b-9ae7-4f67-9bf8-e3f9b352179b'),(32,NULL,'app','m161006_205918_schemaVersion_not_null','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','d5553e45-6e96-4053-a147-9250668b5676'),(33,NULL,'app','m161007_130653_update_email_settings','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','3544e404-5981-437b-a8e0-c9bad9a557d4'),(34,NULL,'app','m161013_175052_newParentId','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','044cf4c9-6889-407b-9b2e-6d56eac86b88'),(35,NULL,'app','m161021_102916_fix_recent_entries_widgets','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','06eb528b-55e4-4e79-8ae5-f77256035a1a'),(36,NULL,'app','m161021_182140_rename_get_help_widget','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','3c0506f6-f95f-4243-aea0-2eaf5d7b3e60'),(37,NULL,'app','m161025_000000_fix_char_columns','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','73b8be0a-16c8-4faa-a393-a4d7fe2dca31'),(38,NULL,'app','m161029_124145_email_message_languages','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','e0622878-3814-4846-9b47-685af599bab2'),(39,NULL,'app','m161108_000000_new_version_format','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','56d2acf4-2153-4936-9808-2f3be811e5db'),(40,NULL,'app','m161109_000000_index_shuffle','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','d28ea1f3-3767-4dca-bfd4-1b41c087e07f'),(41,NULL,'app','m161122_185500_no_craft_app','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','f4c53cf9-9f29-4261-b4a5-c68692a20f47'),(42,NULL,'app','m161125_150752_clear_urlmanager_cache','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','e3c8e3ef-d6eb-4859-99f0-76c2d8096edc'),(43,NULL,'app','m161220_000000_volumes_hasurl_notnull','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','04c4fb2f-4314-4b99-b1e1-1f4f4d1bd00b'),(44,NULL,'app','m170114_161144_udates_permission','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','f9692624-962d-4d2b-9497-2ba1d1a47345'),(45,NULL,'app','m170120_000000_schema_cleanup','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','8626a42c-3180-4f39-94e6-a75bd6e51b09'),(46,NULL,'app','m170126_000000_assets_focal_point','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','d9126944-1320-49fd-aedc-cc27944c3ea6'),(47,NULL,'app','m170206_142126_system_name','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','646ead4a-2c50-4996-8cca-ddabf53b8f5c'),(48,NULL,'app','m170217_044740_category_branch_limits','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','adb62509-3778-4049-9b20-a7f2c977ddee'),(49,NULL,'app','m170217_120224_asset_indexing_columns','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','3c441cb0-ea20-4eba-b56e-39d01bc3ee5a'),(50,NULL,'app','m170223_224012_plain_text_settings','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','65660c46-c469-449c-a37f-ddab3e2e742f'),(51,NULL,'app','m170227_120814_focal_point_percentage','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','6ae030f2-0044-4a30-8157-91a81aea1dc9'),(52,NULL,'app','m170228_171113_system_messages','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','1e918692-16ff-4715-906e-410e78774a37'),(53,NULL,'app','m170303_140500_asset_field_source_settings','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','f765d9a1-6425-4386-a13b-2aec2aabd796'),(54,NULL,'app','m170306_150500_asset_temporary_uploads','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','3e151909-34de-4bc0-9c4f-ff82b84fb64a'),(55,NULL,'app','m170414_162429_rich_text_config_setting','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','59892d98-3371-4482-b01b-f364f5965c6b'),(56,NULL,'app','m170523_190652_element_field_layout_ids','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','42766fc4-30bc-4ca0-b556-5b2a042f946d'),(57,NULL,'app','m170612_000000_route_index_shuffle','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','3b4d19db-361b-4f03-8026-d96084df2059'),(58,NULL,'app','m170621_195237_format_plugin_handles','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','0776ce6f-5cd7-4ffa-8578-434060f80bd5'),(59,NULL,'app','m170630_161028_deprecation_changes','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','2ff7e4bb-a7a7-462f-9b82-86ae19dd5af8'),(60,NULL,'app','m170703_181539_plugins_table_tweaks','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','07c7a0ef-b013-46ae-a500-ae42bd2cab2c'),(61,NULL,'app','m170704_134916_sites_tables','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','5e5a746e-b0b8-4b2c-b5bf-faa36c6412ab'),(62,NULL,'app','m170706_183216_rename_sequences','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','1d42796b-99ce-430f-b1d8-1d1f41daa756'),(63,NULL,'app','m170707_094758_delete_compiled_traits','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','ba6fbb21-765a-447d-8662-656db636d570'),(64,NULL,'app','m170731_190138_drop_asset_packagist','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','486115c5-7c7c-439d-93ba-48ccd06cac2f'),(65,NULL,'app','m170810_201318_create_queue_table','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','89b8b813-c973-43e6-a975-cf4cda99faff'),(66,NULL,'app','m170816_133741_delete_compiled_behaviors','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','bcca8251-91c0-468f-9f9c-fab48521fcfb'),(67,NULL,'app','m170821_180624_deprecation_line_nullable','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','0494c7cc-dd03-45fa-bac3-4b3dac2f006b'),(68,NULL,'app','m170903_192801_longblob_for_queue_jobs','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','b3f6da4c-8936-4296-8932-441241b22f58'),(69,NULL,'app','m170914_204621_asset_cache_shuffle','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','542b53d1-40d6-4845-b450-d393853cd119'),(70,NULL,'app','m171011_214115_site_groups','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','19e85632-6b77-415d-8b54-09e462aa824b'),(71,NULL,'app','m171012_151440_primary_site','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','3531fdb5-89e7-4293-85b8-0cfe49b78e01'),(72,NULL,'app','m171013_142500_transform_interlace','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','720fe054-27a5-4267-a485-0586cbe54e3d'),(73,NULL,'app','m171016_092553_drop_position_select','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','f64a551d-2501-4f8c-8273-1a84c33a4b9f'),(74,NULL,'app','m171016_221244_less_strict_translation_method','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','aa9d667b-fa21-47bc-b3c5-a09baca27651'),(75,NULL,'app','m171107_000000_assign_group_permissions','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','065a476d-e9d8-42d6-8425-e09123a78214'),(76,NULL,'app','m171117_000001_templatecache_index_tune','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','96f888f7-c3d7-4b2a-83d4-7aa67367c054'),(77,NULL,'app','m171126_105927_disabled_plugins','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','91e2051a-893a-4bc9-98e5-600a4ff697d5'),(78,NULL,'app','m171130_214407_craftidtokens_table','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','21b291db-dc6c-445b-ab12-abfbe1b14296'),(79,NULL,'app','m171202_004225_update_email_settings','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','73e79d9b-6de4-4e2a-8c92-392a94a6c632'),(80,NULL,'app','m171204_000001_templatecache_index_tune_deux','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','dca3b25e-8294-40dd-a881-772038dda47f'),(81,NULL,'app','m171205_130908_remove_craftidtokens_refreshtoken_column','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','15af788d-a09c-41d5-91af-f9a347fa3971'),(82,NULL,'app','m171210_142046_fix_db_routes','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','b17a6053-e384-4482-871d-2c16d4e9563f'),(83,NULL,'app','m171218_143135_longtext_query_column','2017-12-29 00:56:43','2017-12-29 00:56:43','2017-12-29 00:56:43','1a0551f9-34ff-419f-bb82-bd153d05460d'),(84,3,'plugin','Install','2017-12-29 02:42:21','2017-12-29 02:42:21','2017-12-29 02:42:21','d61b1885-8b74-4c5f-bfca-8fcd0b3d9554');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'admin-bar','v3.0.3','3.0.1',NULL,'unknown',1,NULL,'2017-12-29 02:42:12','2017-12-29 02:42:12','2017-12-30 05:29:52','c588698c-e80a-4eb4-940e-bcd385cc411e'),(2,'cp-field-inspect','1.0.2','1.0.0',NULL,'unknown',1,NULL,'2017-12-29 02:42:17','2017-12-29 02:42:17','2017-12-30 05:29:52','24d692fe-ac8b-40bb-ada8-5d08aec3b166'),(3,'redactor','1.0.0.1','1.0.0',NULL,'unknown',1,NULL,'2017-12-29 02:42:21','2017-12-29 02:42:21','2017-12-30 05:29:52','c6494b74-9285-4b3f-a18e-8eebcde41cbf');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (1,1,2,NULL,3,1,'2017-12-29 02:45:32','2017-12-29 02:45:32','d0fdd1e4-d43f-4bd8-85d2-6bac5bf66c28'),(3,5,7,NULL,6,1,'2017-12-30 05:17:26','2017-12-30 05:17:26','f9f2738b-bd09-4c36-bba4-92812293653a'),(4,5,10,NULL,8,1,'2017-12-30 05:17:27','2017-12-30 05:17:27','c2cd5bb2-b9f2-413f-90a7-3e838266bf7c');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `routes`
--

LOCK TABLES `routes` WRITE;
/*!40000 ALTER TABLE `routes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `routes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'username',0,1,' uxakron '),(1,'firstname',0,1,' ux '),(1,'lastname',0,1,' akron '),(1,'fullname',0,1,' ux akron '),(1,'email',0,1,' challahan gmail com '),(1,'slug',0,1,''),(2,'slug',0,1,''),(2,'field',1,1,' ux '),(2,'field',2,1,' a user experience community in northeast ohio '),(3,'filename',0,1,' ux svg '),(3,'extension',0,1,' svg '),(3,'kind',0,1,' image '),(3,'slug',0,1,''),(3,'title',0,1,' ux '),(4,'slug',0,1,' home '),(4,'title',0,1,' home '),(4,'field',3,1,' ux akron is a user experience ux meetup community in northeast ohio primarily serving members from akron canton youngstown and kent anyone is welcome from students and those new to ux to seasoned professionals join our next meeting to get a taste of the great events we offer all year '),(4,'field',4,1,' who we are network ux akron is a user experience ux meetup community in northeast ohio primarily serving members from akron canton youngstown and kent anyone is welcome from students and those new to ux to seasoned professionals join our next meeting to get a taste of the great events we offer all year dark eventslist see more events http www meetup com uxakron see more events http www meetup com uxakron attend an event our monthly events are open to anyone take a look at our list of upcoming meetups and register for one that interests you most events are free of charge light contactform mailing list mail interested in future events enter your information here and we ll send you information about upcoming ux meetups dark '),(5,'slug',0,1,''),(5,'field',11,1,' get in touch '),(5,'field',12,1,' http www facebook com uxakron facebook http www twitter com uxakron twitter https www linkedin com company ux akron linkedin mailto hello uxakron com email '),(5,'field',15,1,' ux akron all rights reserved '),(6,'filename',0,1,' network svg '),(6,'extension',0,1,' svg '),(6,'kind',0,1,' image '),(6,'slug',0,1,''),(6,'title',0,1,' network '),(7,'field',5,1,' network '),(7,'field',6,1,' dark '),(7,'field',7,1,' who we are '),(7,'field',8,1,' ux akron is a user experience ux meetup community in northeast ohio primarily serving members from akron canton youngstown and kent anyone is welcome from students and those new to ux to seasoned professionals join our next meeting to get a taste of the great events we offer all year '),(7,'field',9,1,''),(7,'field',10,1,''),(7,'slug',0,1,''),(8,'filename',0,1,' mail svg '),(8,'extension',0,1,' svg '),(8,'kind',0,1,' image '),(8,'slug',0,1,''),(8,'title',0,1,' mail '),(9,'field',5,1,''),(9,'field',6,1,' light '),(9,'field',7,1,' attend an event '),(9,'field',8,1,' our monthly events are open to anyone take a look at our list of upcoming meetups and register for one that interests you most events are free of charge '),(9,'field',9,1,' see more events http www meetup com uxakron see more events http www meetup com uxakron '),(9,'field',10,1,' eventslist '),(9,'slug',0,1,''),(10,'field',5,1,' mail '),(10,'field',6,1,' dark '),(10,'field',7,1,' mailing list '),(10,'field',8,1,' interested in future events enter your information here and we ll send you information about upcoming ux meetups '),(10,'field',9,1,''),(10,'field',10,1,' contactform '),(10,'slug',0,1,''),(11,'field',13,1,' facebook '),(11,'field',14,1,' http www facebook com uxakron '),(11,'slug',0,1,''),(12,'field',13,1,' twitter '),(12,'field',14,1,' http www twitter com uxakron '),(12,'slug',0,1,''),(13,'field',13,1,' linkedin '),(13,'field',14,1,' https www linkedin com company ux akron '),(13,'slug',0,1,''),(14,'field',13,1,' email '),(14,'field',14,1,' mailto hello uxakron com '),(14,'slug',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'Home','home','single',1,'2017-12-29 03:12:21','2017-12-29 03:12:21','737c1e97-2b90-4905-8b3b-48557b435379');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,1,'__home__','index.html','2017-12-29 03:12:21','2017-12-29 03:12:21','360c2701-9343-4b15-8c08-f2779d3635d4');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'UX Akron','2017-12-29 00:56:40','2017-12-29 00:56:40','6d9150ab-96cc-49f8-8528-38a5e5253478');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'UX Akron','default','en-US',1,'https://uxakron.com/',1,'2017-12-29 00:56:40','2017-12-29 02:46:02','58678062-c2b5-41f7-8d3a-99d82a9ea9d3');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemsettings`
--

LOCK TABLES `systemsettings` WRITE;
/*!40000 ALTER TABLE `systemsettings` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `systemsettings` VALUES (1,'email','{\"fromEmail\":\"challahan@gmail.com\",\"fromName\":\"UX Akron\",\"transportType\":\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"}','2017-12-29 00:56:42','2017-12-29 00:56:42','f89c8507-4f95-4237-9837-b013bc3a39bb');
/*!40000 ALTER TABLE `systemsettings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `templatecachequeries`
--

LOCK TABLES `templatecachequeries` WRITE;
/*!40000 ALTER TABLE `templatecachequeries` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `templatecachequeries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\",\"weekStartDay\":\"0\",\"enableDebugToolbarForSite\":false,\"enableDebugToolbarForCp\":false}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,'uxakron',NULL,'UX','Akron','challahan@gmail.com','$2y$13$ymUmaEnfT/CqUMy64P.hsOvfY72wpgl/pw7Hr4yFZSp.WlorZ72ZG',1,0,0,0,0,0,'2017-12-30 04:53:08','174.104.113.76',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2017-12-29 02:47:39','2017-12-29 00:56:42','2017-12-30 04:53:08','33714db1-6d51-4680-8917-fcda437cd0fe');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Global','','2017-12-29 02:43:44','2017-12-29 02:43:44','318b0a06-19e1-4d39-895b-b11b9cff78ca'),(2,NULL,NULL,'Temporary source',NULL,'2017-12-29 02:44:47','2017-12-29 02:44:47','7138ed06-64dd-410c-a879-cdfc5ab43608'),(3,2,NULL,'user_1','user_1/','2017-12-29 02:44:47','2017-12-29 02:44:47','ce427830-a94e-4e5b-8b85-51dfb15128e8');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,1,'Global','global','craft\\volumes\\Local',1,'assets/img/uploads/global','{\"path\":\"assets/img/uploads/global\"}',1,'2017-12-29 02:43:44','2017-12-29 02:43:44','41585d4f-4ed7-450e-aa9a-fe19ebba92e2');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,0,'{\"section\":\"*\",\"siteId\":\"1\",\"limit\":10}',1,'2017-12-29 00:56:44','2017-12-29 00:56:44','ab9c8d24-1ec7-43df-8cc5-741477571d20'),(2,1,'craft\\widgets\\CraftSupport',2,0,'[]',1,'2017-12-29 00:56:44','2017-12-29 00:56:44','7692ee1d-aed4-4e5f-a08b-a81e8e0da716'),(3,1,'craft\\widgets\\Updates',3,0,'[]',1,'2017-12-29 00:56:44','2017-12-29 00:56:44','50261c0e-3515-4f92-9337-69515620a5dc'),(4,1,'craft\\widgets\\Feed',4,0,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2017-12-29 00:56:44','2017-12-29 00:56:44','820f4223-29d4-4a27-b8f4-8544695581fb');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'uxakron_web'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-29 21:30:47
